#!/bin/sh
java -Xms32m -Xmx96m -cp Caliph.jar at.lux.fotoretrieval.RetrievalFrame