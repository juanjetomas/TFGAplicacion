#!/bin/sh
java -Xms32m -Xmx96m -jar Caliph.jar