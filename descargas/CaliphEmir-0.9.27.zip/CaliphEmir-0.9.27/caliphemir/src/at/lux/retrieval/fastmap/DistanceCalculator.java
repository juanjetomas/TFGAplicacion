/*
 * This file is part of Caliph & Emir.
 *
 * Caliph & Emir is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Caliph & Emir is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Caliph & Emir; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Copyright statement:
 * --------------------
 * (c) 2002-2005 by Mathias Lux (mathias@juggle.at)
 * http://www.juggle.at, http://caliph-emir.sourceforge.net
 */
package at.lux.retrieval.fastmap;

/**
 * Date: 13.01.2005
 * Time: 22:37:22
 *
 * @author Mathias Lux, mathias@juggle.at
 */
public abstract class DistanceCalculator {
    /**
     * Calculates and returns the distance between two objects. Please note that the
     * distance function has to be symmetric and must obey the triangle inequality.
     * This method is the same as {@link #getDistance(Object, Object, int, float[], float[])}
     * with a k=0.
     *
     * @param o1 Object 1 to compute
     * @param o2 Object 2 to compute
     * @return the distance as float from [0, infinite)  or -1 if objects distance cannot be computed
     */
    abstract public float getDistance(Object o1, Object o2);

    /**
     * Calculates and returns the distance between two objects. Please note that the
     * distance function has to be symmetric and must obey the triangle inequality.
     * distance in k is: d[k+1](o1,o2)^2 = d[k](o1,o2)^2 - (x1[k]-x2[k])^2 .
     *
     * @param o1 Object 1 to compute
     * @param o2 Object 2 to compute
     * @param k  defines the dimension of current fastmap operation
     * @param x1 is needed when k > 0 (see documentation above), all x1[l] with l &lt; k have to be present.
     * @param x2 is needed when k > 0 (see documentation above), all x2[l] with l &lt; k have to be present.
     * @return the distance as float from [0, infinite)  or -1 if objects distance cannot be computes
     */
    public float getDistance(Object o1, Object o2, int k, float[] x1, float[] x2) {
        float originalDistance = getDistance(o1, o2);
        if (k == 0) {
            return originalDistance;
        } else {
            float distance = originalDistance * originalDistance;
            for (int i = 0; i < k; i++) {
                float xDifference = x1[i] - x2[i];
                distance = distance - xDifference * xDifference;
            }
            return (float) Math.sqrt(distance);
        }
    }
}
