Please note: The Batik libraries are needed to compile the source.
If the libraries are not present at runtime, the SVG export will be
disabled, but the application will function as normal.