# Caliph and Emir
MPEG-7 image annotation and retrieval GUI tools. Caliph is short for Common And Light-weight PHoto annotation and
provides means to create a MPEG-7 XML based description of a photo. Emir is short for Experimental Metadata based
Image Retrieval and uses the metadata created by Caliph for retrieval.

# Citations
If you use this software in research please cite

Lux, Mathias. "Caliph & Emir: MPEG-7 photo annotation and retrieval." Proceedings of the 17th ACM international conference on Multimedia. ACM, 2009.


